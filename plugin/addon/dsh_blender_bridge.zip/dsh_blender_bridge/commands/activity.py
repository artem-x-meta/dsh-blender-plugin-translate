""" Activity state and human activity commands. """

from ..protocol import ai_paused
from ..recorders.activity import get_activity_tracker
from ..recorders.user_edit import get_edit_recorder

class ActivityCommands:
    def get_activity_state(self):
        """v1.8: unified activity state (human / agent / idle / both) + native selection summary."""
        try:
            # A query command must not count itself as agent (otherwise every query returns state=agent)
            snap = get_activity_tracker().snapshot(include_current_command=False)
            snap["paused"] = ai_paused()
            return snap
        except Exception as e:
            print(f"Error getting activity state: {str(e)}")
            return {"error": str(e)}

    def drain_human_activity(self):
        """Return human-originated events buffered since the last drain.

        Consent is enforced DSH-side (the plugin only drains and uploads when
        the user has opted in), but we also refuse here so a buffer does not
        accumulate for a user who has said no.
        """
        try:
            if not self.get_telemetry_consent().get("consent"):  # pyright: ignore[reportAttributeAccessIssue]
                get_edit_recorder().drain()
                return {"events": []}
            return {"events": get_edit_recorder().drain()}
        except Exception as e:
            print(f"Error draining manual edits: {str(e)}")
            return {"error": str(e)}
